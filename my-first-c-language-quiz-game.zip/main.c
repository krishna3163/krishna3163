#include <stdio.h>

int main() {
    int score = 0;
    
    printf("Welcome to the Quiz Game!\n");
    printf("Question 1: What is the capital of France?\n");
    printf("A. Paris\nB. Berlin\nC. Rome\n");
    
    char answer1 = getchar();
    if (answer1 == 'A' || answer1 == 'a') {
        printf("Correct!\n");
        score++;
    } else {
        printf("Incorrect.\n");
    }
    
    printf("Question 2: What is the largest country in the world by land area?\n");
    printf("A. Russia\nB. Canada\nC. China\n");
    
    char answer2 = getchar();
    if (answer2 == 'A' || answer2 == 'a') {
        printf("Correct!\n");
        score++;
    } else {
        printf("Incorrect.\n");
    }
    
    printf("Question 3: Who is the CEO of Tesla?\n");
    printf("A. Jeff Bezos\nB. Mark Zuckerberg\nC. Elon Musk\n");
    
    char answer3 = getchar();
    if (answer3 == 'C' || answer3 == 'c') {
        printf("Correct!\n");
        score++;
    } else {
        printf("Incorrect.\n");
    }
    
    printf("Your final score is %d out of 3.\n", score);
    return 0;
}
